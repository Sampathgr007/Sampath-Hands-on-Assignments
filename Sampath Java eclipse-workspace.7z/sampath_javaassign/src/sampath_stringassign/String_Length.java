package sampath_stringassign;

public class String_Length {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello World";
		int s1=str.length();
		System.out.println("The Length of "+"Hello World is :"+s1);

	}

}
