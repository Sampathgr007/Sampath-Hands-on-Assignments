package sampath_stringassign;

public class Joinstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str ="Hello";
		System.out.println("Original String :"+str);
		  String str1=str.concat(" How Are You");
		  System.out.println("Updated String :"+str1);

	}

}