module sampath_javaassign {
	requires java.sql;
}