package Sampath_CollectionAssign;

import java.util.*;
public class TreeSet_Q2 {
public static void main(String[] args) {
	TreeSet<String> s=new TreeSet<String>();
	s.add("Virat");
	s.add("Sachin");
	s.add("Dhoni");
	s.add("Rishabh");
	s.add("Warner");
	s.add("Miller");
	s.add("Bravo");
	s.add("Pollard");
	s.add("Southee");
	s.add("Boult");
	System.out.println(s);
}
}