package Sampath_CollectionAssign;

import java.util.*;
public class UsingArrayList_Q2 {
public static void main(String[] args) {
	ArrayList<String> a=new ArrayList<>();
	a.add("Virat");
	a.add("Virat");
	a.add("Dhoni");
	a.add("Rishabh");
	a.add("Warner");
	a.add("Miller");
	a.add("Bravo");
	a.add("Pollard");
	a.add("Southee");
	a.add("Boult");
	System.out.println(a);
}
}