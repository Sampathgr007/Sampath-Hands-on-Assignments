package HierarchyOfanOrganisation;

	import java.util.Scanner;

	public abstract class Employee {
		abstract void TotalSalary(int Salary);
	}

