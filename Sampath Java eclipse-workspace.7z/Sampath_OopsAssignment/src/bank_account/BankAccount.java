package bank_account;


public abstract class BankAccount {
	
	abstract void totalcash(int cash) ;
	
}